# પ્રવાસ ડાયરી અને યાદો (Travel Diary & Memories)

ગુજરાતી ભાષાની અલગ Android એપ. નોંધો, તારીખ, સ્થળ, ટૅગ્સ, મનપસંદ યાદો અને ફોટા ફોનમાં જ સાચવે છે. ઇન્ટરનેટ વગર નોંધો બનાવવી અને વાંચવી શક્ય છે.

## મુખ્ય સુવિધાઓ
- દિવસ/તારીખ મુજબ પ્રવાસની યાદો અને વાર્તાઓ
- ફોટો ઉમેરવો (દરેક ફોટો 5 MB સુધી)
- સ્થળ, ટૅગ્સ, મનપસંદ, શોધ અને તારીખ પ્રમાણે ગોઠવણી
- યાદમાં ફેરફાર, શેરિંગ અને કાઢી નાખવું
- JSON બૅકઅપ Export તથા Import
- પ્રિન્ટ મેનૂથી PDF તરીકે સેવ કરવાનો વિકલ્પ
- Android WebView wrapper; બહારની વેબ લિંક બ્રાઉઝરમાં ખોલે છે

## GitHub Actionsથી APK બનાવવાની રીત
1. આ ZIPને GitHub રિપોઝિટરીના મુખ્ય પેજ પર `TravelDiaryMemories.zip` નામે અપલોડ કરો.
2. ZIPમાંથી `.github/workflows/build-apk.yml` ફાઇલ Extract કરીને GitHubમાં એ જ પાથ પર ઉમેરો: `.github/workflows/build-apk.yml`.
3. Commit કરો. `Actions` ખોલીને `Build Travel Diary APK` પસંદ કરો.
4. `Run workflow` દબાવો અથવા ZIP commit પછી શરૂ થયેલો workflow ખોલો.
5. સફળ Build પછી Artifact `travel-diary-memories-debug-apk` ડાઉનલોડ કરો; તેમાં `app-debug.apk` હશે.

## નોંધો
- આ પ્રોજેક્ટ સોર્સ ZIP છે; અહીં APKનું વાસ્તવિક Android Build અથવા ડિવાઇસ પરીક્ષણ કરવામાં આવ્યું નથી. APK GitHub Actions પર Build કરવાનું છે.
- ફોટા browser/WebView local storageમાં base64 રૂપે રહે છે. ઘણા મોટા ફોટા ઉમેરવાથી સ્ટોરેજ મર્યાદા આવી શકે છે; ફોટા 5 MB સુધી મર્યાદિત છે.
- એપ ડેટા સાફ કરવાથી અથવા uninstall કરવાથી સ્થાનિક યાદો ગુમાઈ શકે છે. સમયાંતરે `વધુ → બૅકઅપ લો` વાપરો અને JSON ફાઇલ સુરક્ષિત રાખો.
- PDF માટે પ્રિન્ટ મેનૂ/Print to PDF વિકલ્પ Android WebView અને ફોનના પ્રિન્ટ સપોર્ટ પર આધારિત છે.
